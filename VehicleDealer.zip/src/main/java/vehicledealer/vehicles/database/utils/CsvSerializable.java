package vehicledealer.vehicles.database.utils;

public interface CsvSerializable {
    String toCsv();
}
