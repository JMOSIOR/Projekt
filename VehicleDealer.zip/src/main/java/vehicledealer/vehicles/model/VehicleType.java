package vehicledealer.vehicles.model;

public enum VehicleType {
    CAR, MOTOCYCLE
}
